package it.mws2018039.testlistview;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class RowAdapter extends ArrayAdapter<String> {
    private Context context;
    private List<String> elenco;

    public RowAdapter(Context context, List<String> objects) {
        super(context, R.layout.activity_row_adapter, objects);
        this.context = context;
        this.elenco = objects;
    }

    // position final per renderla visibile all'interno dell'anonymous-inner-class (listener)
    @Override
    public View getView(int position, View view, final ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView= inflater.inflate(R.layout.activity_row_adapter, null, true);
        TextView txtLabel = rowView.findViewById(R.id.row_label);
        LinearLayout rowLayout = rowView.findViewById(R.id.row_layout);

        final String val = elenco.get(position);

        //rowLayout.setBackgroundColor( rowView.getResources().getColor(R.color.colorDispari));
        if( position % 2 == 0){
            rowLayout.setBackgroundResource( R.color.colorPari );
        } else {
            rowLayout.setBackgroundResource( R.color.colorDispari );
        }


        txtLabel.setText(val);

        // recupero ImageView dell'icone e registro un listener
        ImageView iconaIV = rowView.findViewById(R.id.row_icon);
        iconaIV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("ADAPTER", "click di: "+ val);
                Toast.makeText(context, "Ho cliccato "+ val, Toast.LENGTH_LONG).show();
            }
        });

        ImageView ballIV = rowView.findViewById(R.id.row_ball);
        if( val.equalsIgnoreCase("lele") ){
            ballIV.setImageResource( R.mipmap.ball_red );
        } else {
            ballIV.setImageResource( R.mipmap.ball_green );
        }

        return rowView;
    }

}
