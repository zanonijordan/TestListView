package it.mws2018039.testlistview;

import android.app.ListActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<String> elenco = new ArrayList<>();
        elenco.add("Uno");
        elenco.add("Lele");
        elenco.add("Tre");
        elenco.add("Quattro");
        elenco.add("Lele");
        for(int i=0;i<20;i++) elenco.add("Riga "+i);
        elenco.add("Lele");

        RowAdapter adapter = new RowAdapter(this, elenco);
        setListAdapter( adapter );
    }
}
